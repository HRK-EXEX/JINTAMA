// ユーティリティ関数
export class Utility {
    toRadian = (degrees) => {
        return degrees * Math.PI / 180;
    };
}