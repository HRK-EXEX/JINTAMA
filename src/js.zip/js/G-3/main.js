import { MainScene } from "./mainScene.js";

const DEFAULT_WIDTH = window.innerWidth
const DEFAULT_HEIGHT = window.innerHeight // any height you want

function getSessionData() {
    try {
        const element = document.getElementById('session-data');
        const jsonText = element.textContent.trim();
        console.log('JSON内容:', jsonText);
        return JSON.parse(jsonText);
    } catch (error) {
        console.error('JSONパースエラー:', error);
        return null;
    }
}

export var playerData = getSessionData();
export var playerData2 = document.getElementById('session-data');

// console.log(playerData);
// console.log(playerData2);

//ゲームに関する設定
const CONFIG = {
    mode: Phaser.Scale.FIT,
    type: Phaser.AUTO,
    width: DEFAULT_WIDTH,
    height: DEFAULT_HEIGHT,
    scene: MainScene,
    antialias: false
}

//ゲームオブジェクトの生成
const GAME = new Phaser.Game(CONFIG)
